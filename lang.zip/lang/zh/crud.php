<?php

return [

    'add_new' => '添新',
    'cancel' => '取消',
    'save' => '保存',
    'edit' => '編輯',
    'detail' => '細節',
    'back' => '後退',
    'action' => '行動',
    'id' => 'ID',
    'created_at' => '創建於',
    'updated_at' => '更新於',
    'deleted_at' => '刪除於',
    'are_you_sure' => '你確定嗎？',
];
