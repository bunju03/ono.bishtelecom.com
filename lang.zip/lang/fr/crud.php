<?php

return [

    'add_new' => 'Ajouter nouveau',
    'cancel' => 'Annuler',
    'save' => 'Sauvegarder',
    'edit' => 'Éditer',
    'detail' => 'Détail',
    'back' => 'Retour',
    'action' => 'action',
    'id' => 'Identifiant',
    'created_at' => 'Créé à',
    'updated_at' => 'Mis à jour à',
    'deleted_at' => 'Supprimé à',
    'are_you_sure' => 'Es-tu sûr?',
];
