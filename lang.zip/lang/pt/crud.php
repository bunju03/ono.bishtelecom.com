<?php

return [

    'add_new' => 'Add New',
    'cancel' => 'Cancelar',
    'save' => 'Salve',
    'edit' => 'Editar',
    'detail' => 'Detalhe',
    'back' => 'Costas',
    'action' => 'Açao',
    'id' => 'Eu ia',
    'created_at' => 'Criado em',
    'updated_at' => 'Atualizado em',
    'deleted_at' => 'Excluído em',
    'are_you_sure' => 'Tem certeza?',
];
