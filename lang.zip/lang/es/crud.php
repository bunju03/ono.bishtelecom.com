<?php

return [

    'add_new' => 'Agregar nuevo',
    'cancel' => 'Cancelar',
    'save' => 'Ahorrar',
    'edit' => 'Editar',
    'detail' => 'Detail',
    'back' => 'atrás',
    'action' => 'Acción',
    'id' => 'Identificación',
    'created_at' => 'Creado en',
    'updated_at' => 'Actualizado en',
    'deleted_at' => 'Eliminado en',
    'are_you_sure' => 'Estas seguro',
];
