<?php

return [

    'add_new' => 'اضف جديد',
    'cancel' => 'يلغي',
    'save' => 'يحفظ',
    'edit' => 'تعديل',
    'detail' => 'التفاصيل',
    'back' => 'عودة',
    'action' => 'عمل',
    'id' => 'بطاقة تعريف',
    'created_at' => 'أنشئت في',
    'updated_at' => 'تم التحديث في',
    'deleted_at' => 'محذوف في',
    'are_you_sure' => 'هل أنت متأكد؟',
];
