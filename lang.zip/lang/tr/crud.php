<?php

return [

    'add_new' => 'Yeni ekle',
    'cancel' => 'İptal etmek',
    'save' => 'Kayıt etmek',
    'edit' => 'Düzenlemek',
    'detail' => 'detay',
    'back' => 'geri',
    'action' => 'Eylem',
    'id' => 'İD',
    'created_at' => 'Oluşturulma Tarihi',
    'updated_at' => 'Güncellenme Tarihi',
    'deleted_at' => 'Silinme Tarihi',
    'are_you_sure' => 'Emin misin?',
];
